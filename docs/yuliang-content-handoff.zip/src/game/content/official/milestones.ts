import type { MilestoneDefinition } from '../contracts';
export const officialMilestones = [] satisfies readonly MilestoneDefinition[];
