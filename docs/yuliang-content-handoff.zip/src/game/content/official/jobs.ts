import type { JobDefinition } from '../contracts';
export const officialJobs = [] satisfies readonly JobDefinition[];
