import type { ItemDefinition } from '../contracts';
export const officialItems = [] satisfies readonly ItemDefinition[];
