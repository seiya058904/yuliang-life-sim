import type { BusinessDefinition } from '../contracts';
export const officialBusinesses = [] satisfies readonly BusinessDefinition[];
