import type { AssetDefinition } from '../contracts';
export const officialAssets = [] satisfies readonly AssetDefinition[];
