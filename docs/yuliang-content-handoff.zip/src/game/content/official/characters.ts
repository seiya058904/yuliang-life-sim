import type { CharacterDefinition } from '../contracts';
export const officialCharacters = [] satisfies readonly CharacterDefinition[];
