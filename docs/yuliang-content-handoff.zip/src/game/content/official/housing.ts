import type { HousingDefinition } from '../contracts';
export const officialHousing = [] satisfies readonly HousingDefinition[];
