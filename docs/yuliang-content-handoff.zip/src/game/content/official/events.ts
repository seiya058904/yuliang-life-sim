import type { EventDefinition } from '../contracts';
export const officialEvents = [] satisfies readonly EventDefinition[];
