import type { EventChainDefinition } from '../contracts';
export const officialEventChains = [] satisfies readonly EventChainDefinition[];
