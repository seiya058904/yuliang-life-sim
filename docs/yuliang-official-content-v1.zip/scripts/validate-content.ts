import { contentRegistry } from '../src/game/content/registry';
import { validateContent } from '../src/game/content/validateContent';

const result = validateContent(contentRegistry);
if (!result.valid) {
  console.error(result.errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(`内容验证通过：${contentRegistry.jobs.length} 个工作、${contentRegistry.items.length} 件商品、${contentRegistry.events.length} 个事件。`);
}
