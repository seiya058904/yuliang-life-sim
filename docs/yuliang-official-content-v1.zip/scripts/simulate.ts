import { balanceConfig } from '../src/game/balance/config';
import { contentRegistry } from '../src/game/content/registry';
import { dispatchGameAction } from '../src/game/engine/actions';
import { createInitialState } from '../src/game/engine/initialState';
import { calculateNetWorth } from '../src/game/engine/economy';
import type { GameAction, GameState } from '../src/game/content/contracts';

type Strategy = 'career' | 'consumer' | 'relationship' | 'investor';

function chooseAction(state: GameState, strategy: Strategy): GameAction {
  if (state.pendingEventId) return { type: 'choose_event', eventId: state.pendingEventId, choiceId: contentRegistry.events.find((event) => event.id === state.pendingEventId)?.choices[0]?.id ?? '' };
  if (strategy === 'relationship' && state.time.hour % 8 === 0) return { type: 'rest' };
  if (strategy === 'consumer' && state.cash > 450 && !(state.inventory['item.seed-phone'] ?? 0)) return { type: 'purchase_items', items: { 'item.seed-phone': 1 } };
  if (strategy === 'consumer' && state.cash > 900 && !(state.inventory['item.seed-laptop'] ?? 0)) return { type: 'purchase_items', items: { 'item.seed-laptop': 1 } };
  if (strategy === 'investor' && state.unlockedAssetIds.includes('asset.seed-rental') && state.cash > 5100 && !state.assets['asset.seed-rental']) return { type: 'buy_asset', assetId: 'asset.seed-rental' };
  if (strategy === 'relationship') return { type: 'study' };
  return { type: 'work', jobId: state.currentJobId ?? 'job.seed-shop-clerk' };
}

function run(strategy: Strategy): { strategy: Strategy; day: number; cash: number; netWorth: number; errors: number } {
  let state = createInitialState(contentRegistry, balanceConfig, 20260825);
  let errors = 0;
  let guard = 0;
  while (state.time.day <= 60 && guard < 500) {
    const result = dispatchGameAction(state, chooseAction(state, strategy), contentRegistry, balanceConfig);
    if (result.error) { errors += 1; state = dispatchGameAction(state, { type: 'rest' }, contentRegistry, balanceConfig).state; } else state = result.state;
    guard += 1;
  }
  return { strategy, day: state.time.day, cash: state.cash, netWorth: calculateNetWorth(state, contentRegistry, balanceConfig), errors };
}

for (const strategy of ['career', 'consumer', 'relationship', 'investor'] as const) console.log(JSON.stringify(run(strategy)));
