# 《余量》正式内容包 v1 — 交接校验

## 已完成校验

- TypeScript 严格类型检查：通过（使用交接包中的真实 Content Contract，并仅为缺失的 `GameTime` 类型提供临时检查桩；检查桩不包含在交付包中）。
- `validateContent(contentRegistry)`：通过，0 errors。
- Registry 内容状态：工作、商品、住房、企业、资产、人物、事件、事件链、里程碑全部为 `official`，没有残留可见 Seed 条目。
- 数量：12 工作、28 商品、6 住房、3 企业、4 资产、5 人物、28 事件、4 条事件链、8 里程碑。
- 所有稳定 ID、Tag、Capability、跨内容引用、事件链映射与事件正向选项均通过验证。

## 尚需在完整工程中执行

当前交接 ZIP 不包含完整 `src/game/engine`、React UI、node_modules 与 Playwright 工程，因此这里没有冒充执行完整 `npm test / content:simulate / e2e / build`。

将本内容包合入完整项目后，请由工程 Agent 依次执行：

```bash
npm run content:validate
npm test
npm run content:simulate
npm run build
npm run e2e
```

重点观察实际分钟节奏、远程工作重复收益、企业 modifier 长局叠加、关系链可达性和第一笔被动收入出现时间，再进行第二轮纯数值调参。
