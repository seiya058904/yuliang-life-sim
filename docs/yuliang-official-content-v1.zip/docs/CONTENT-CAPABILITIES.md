# 《余量》内容能力清单

这是给内容设计 AI 的速查表。详细字段以 `src/game/content/contracts.ts` 为准；不需要阅读核心引擎即可按下列能力填写内容。

## Condition

`all`、`any`、`not`；`day_at_least`、`day_at_most`、`time_between`；`player_stage`；`cash_at_least`、`ability_at_least`、`reputation_at_least`、`lifestyle_at_least`；`current_job`、`job_experience_at_least`；`owns_item`、`has_capability`；`housing_is`；`owns_business`、`owns_asset`；`relationship_at_least`、`relationship_stage_at_least`；`completed_event`、`completed_milestone`；`chain_stage_at_least`；`flag`。

## Effect

`cash`（可选 `rewardTier`）、`stat`（`ability` / `reputation` / `lifestyle`）、`relation`、`item`、`unlock_capability`、`unlock_job`、`unlock_event`、`unlock_housing`、`unlock_business`、`unlock_asset`、`discount`、`modifier`、`advance_time`、`set_flag`、`advance_chain`。

## Modifier

目标：`work_pay`、`work_hours`、`study_gain`、`business_profit`、`housing_rent`、`shop_price`、`event_reward`。

操作：`add` 或 `multiply`。可选 `tags` 作为适用范围。乘法值必须大于 0；工作时间、租金和商店价格低于 1 的乘数代表正向改善。

## Capability

- `remote_work`：解锁远程工作。
- `home_workspace`：满足办公室类工作或在家工作的条件。
- `business_license`：满足基础企业机会的经营条件。
- `market_insight`：供正式内容扩展投资或市场事件使用。

新增 Capability 必须先加入 `src/game/content/vocabulary.ts`，再在内容中引用。

## Tag

当前 Tag：`work`、`office`、`remote`、`starter`、`technology`、`clothing`、`furniture`、`luxury`、`collectible`、`housing`、`business`、`asset`、`relationship`、`life`、`luck`、`career`、`shopping`。

Tag 用于内容筛选、折扣和 modifier 适用范围。新增 Tag 必须注册后使用。

## Reward Tier

- `small`：`0.55×`
- `normal`：`1×`
- `large`：`1.8×`
- `milestone`：`3×`

倍率属于引擎 Balance 配置；内容只选择 tier，不复制公式。

## 关键阶段阈值

- 玩家阶段：`start` ¥0、`growing` ¥2,500、`stable` ¥10,000、`wealthy` ¥50,000 净资产。
- 关系阶段：0、25、50、75。
- 初始状态：现金 ¥500、能力 10、声誉 0、生活水平 10、第 1 天 08:00。
- 事件默认目标：平均每天 1–2 个，单日上限 2 个。
- 住房周转保护冷却：14 天；仅作为现金不足的兜底保护。

如果正式内容需要调整阈值，应修改 Balance 配置并重新运行 validator、60 天策略模拟和浏览器试玩。
