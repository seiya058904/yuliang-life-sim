# 《余量》内容填写指南

内容只修改 `src/game/content/official/` 下对应类别文件，不修改引擎、dispatcher 或 React 组件。每个正式内容使用稳定的 ASCII ID；中文 `name`、`description`、事件正文和选项文案可以随时修改，不能用中文文案作为引用。

## 文件与渐进替换

- `src/game/content/contracts.ts`：所有 Definition、Condition、Effect、Modifier 类型。
- `src/game/content/official/jobs.ts`：正式工作；当前为空时使用 Seed 工作。
- `src/game/content/official/items.ts`：正式商品；当前为空时使用 Seed 商品。
- `src/game/content/official/housing.ts`：正式住房。
- `src/game/content/official/businesses.ts`：正式企业。
- `src/game/content/official/assets.ts`：正式资产。
- `src/game/content/official/characters.ts`：正式人物。
- `src/game/content/official/events.ts`：正式事件。
- `src/game/content/official/eventChains.ts`：正式事件链。
- `src/game/content/official/milestones.ts`：正式里程碑。
- `src/game/content/vocabulary.ts`：Capability 与 Tag 注册表。
- `src/game/balance/config.ts`：集中平衡参数，不在内容文件复制公式。

每类 Official 数组中的条目会按 ID 覆盖对应 Seed 条目，未覆盖的 Seed 条目继续保留；因此可以先替换一个工作或一个事件而不破坏其他内容。每次替换后运行 `npm run content:validate`、`npm run content:simulate` 和 `npm run e2e`。
替换已有 Seed 条目时保留原 ID；如果确实要新增条目，才分配新的稳定 ID。这样其他类别的引用和旧存档都不需要迁移。

## 写法规则

- ID 使用稳定的小写 ASCII，例如 `job.office-assistant`；不要从中文名称生成 ID。
- 数值只填写该内容的基础值；工资、净资产、企业利润、奖励 tier 缩放和事件抽取由引擎计算。
- `conditions` 可用 `all`、`any`、`not` 组合；引用其他内容时必须使用稳定 ID。
- `effects` 是声明式数组，不能填写函数。可使用现金、属性、关系、商品、解锁、折扣、永久 modifier、时间和事件链推进。
- 事件每个选项都必须有整体正向价值。允许现金/时间成本换能力、关系、永久 modifier、解锁或机会；禁止无补偿纯负面结果。
- Modifier 只能使用能力清单中的目标、操作和 Tag 选择器。
- 事件链只声明阶段、事件 ID、等待天数和条件；不要创建新的剧情执行逻辑。
- 商品、住房、企业和资产的解锁通过 `unlock_*` effect 或通用条件完成，不在 dispatcher 中写具体 ID。

## 必填字段速查

- 所有内容：`id`、`contentStatus: "official"`、`name`、`description`。
- 工作：`kind`、`hours`、`basePay`、`careerXp`、`isLongTerm`。
- 商品：`category`、`price`、`consumable`、`sellable`、`resaleRatio`、`lifestyleDelta`。
- 住房：`mode`、`rentPerDay`、`valuation`、`lifestyleDelta`、`furnitureCapacity`。
- 企业：`price`、收入/成本基础值及三个档位数组。
- 资产：`kind`、`price`、`valuation`、`dailyIncome`、`volatility`。
- 人物：`identity`、`initialRelationship`、`stages`。
- 事件：`title`、`body`、`category`、`weight`、`cooldownDays`、至少两个 `choices`。
- 事件链：按升序填写 `stages`，每个阶段引用一个已存在事件。

## 验证与交接

`validateContent` 会检查重复 ID、未知引用、无效数值、未知 vocabulary、断裂事件链、不可达事件、事件选项数量和没有整体正向价值的选项。未知或被移除的存档 ID 会在迁移时安全清理并补偿，不会让存档崩溃。

Seed 内容位于 `src/game/content/seed.ts`，只用于框架试玩，不代表正式文案或最终经济平衡。
