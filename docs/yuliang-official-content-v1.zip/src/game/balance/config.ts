import type { CapabilityId, GameState, PlayerStage, RewardTier } from '../content/contracts';

export interface BalanceConfig {
  saveVersion: number;
  contentVersion: number;
  initialCash: number;
  initialAbility: number;
  initialReputation: number;
  initialLifestyle: number;
  initialDay: number;
  initialHour: number;
  startingHousingId: string;
  startingHousingMode: 'rent' | 'owned';
  startingCapabilities: readonly CapabilityId[];
  eventBaseMeterPerHour: number;
  eventMeterThreshold: number;
  eventDailyLimit: number;
  rentReserveDays: number;
  rentReliefCooldownDays: number;
  saleRatioFallback: number;
  businessValuationRatio: number;
  rewardTiers: Record<RewardTier, number>;
  relationshipStageThresholds: readonly number[];
  stageThresholds: Record<PlayerStage, number>;
}

export const balanceConfig: BalanceConfig = {
  saveVersion: 1,
  contentVersion: 1,
  initialCash: 500,
  initialAbility: 10,
  initialReputation: 0,
  initialLifestyle: 10,
  initialDay: 1,
  initialHour: 8,
  startingHousingId: 'housing.shared-room',
  startingHousingMode: 'rent',
  startingCapabilities: [],
  eventBaseMeterPerHour: 0.07,
  eventMeterThreshold: 1,
  eventDailyLimit: 2,
  rentReserveDays: 1,
  rentReliefCooldownDays: 14,
  saleRatioFallback: 0.5,
  businessValuationRatio: 0.65,
  rewardTiers: { small: 0.55, normal: 1, large: 1.8, milestone: 3 },
  relationshipStageThresholds: [0, 25, 50, 75],
  stageThresholds: { start: 0, growing: 2500, stable: 10000, wealthy: 50000 },
};

export function mergeBalanceConfig(overrides: Partial<BalanceConfig> = {}): BalanceConfig {
  return { ...balanceConfig, ...overrides, rewardTiers: { ...balanceConfig.rewardTiers, ...overrides.rewardTiers }, stageThresholds: { ...balanceConfig.stageThresholds, ...overrides.stageThresholds } };
}
