import type {
  ConditionDefinition,
  ContentId,
  ContentRegistry,
  EffectDefinition,
  EventChoiceDefinition,
  PermanentModifierDefinition,
} from './contracts';

export interface ContentValidationResult {
  valid: boolean;
  errors: string[];
}

type ContentCollection = readonly { id: ContentId; name: string; description: string; tags?: readonly string[] }[];

const idPattern = /^[a-z][a-z0-9._-]+$/;

export function validateContent(registry: ContentRegistry): ContentValidationResult {
  const errors: string[] = [];
  const ids = new Map<string, string>();
  const collections: Array<[string, ContentCollection]> = [
    ['工作', registry.jobs], ['商品', registry.items], ['住房', registry.housing],
    ['企业', registry.businesses], ['资产', registry.assets], ['人物', registry.characters],
    ['事件', registry.events], ['事件链', registry.eventChains], ['里程碑', registry.milestones],
  ];
  const known = {
    jobs: new Set(registry.jobs.map((entry) => entry.id)),
    items: new Set(registry.items.map((entry) => entry.id)),
    housing: new Set(registry.housing.map((entry) => entry.id)),
    businesses: new Set(registry.businesses.map((entry) => entry.id)),
    assets: new Set(registry.assets.map((entry) => entry.id)),
    characters: new Set(registry.characters.map((entry) => entry.id)),
    events: new Set(registry.events.map((entry) => entry.id)),
    eventChains: new Set(registry.eventChains.map((entry) => entry.id)),
    milestones: new Set(registry.milestones.map((entry) => entry.id)),
  };

  for (const [category, collection] of collections) {
    for (const entry of collection) {
      if (!idPattern.test(entry.id)) errors.push(`${category} ID 无效: ${entry.id}`);
      if (!entry.name.trim()) errors.push(`${category} ${entry.id} 缺少中文名称`);
      if (!entry.description.trim()) errors.push(`${category} ${entry.id} 缺少简介`);
      if (ids.has(entry.id)) errors.push(`重复 ID: ${entry.id}（${ids.get(entry.id)} 与 ${category}）`);
      ids.set(entry.id, category);
      for (const tag of entry.tags ?? []) {
        if (!registry.vocabulary.tags.includes(tag)) errors.push(`${category} ${entry.id} 引用了未知 Tag: ${tag}`);
      }
    }
  }

  for (const capability of registry.vocabulary.capabilities) {
    if (!idPattern.test(capability)) errors.push(`Capability ID 无效: ${capability}`);
  }

  const checkCondition = (condition: ConditionDefinition | undefined, owner: string): void => {
    if (!condition) return;
    switch (condition.type) {
      case 'all':
      case 'any':
        if (condition.conditions.length === 0) errors.push(`${owner} 的 ${condition.type} 条件不能为空`);
        condition.conditions.forEach((child) => checkCondition(child, owner));
        break;
      case 'not': checkCondition(condition.condition, owner); break;
      case 'current_job':
      case 'job_experience_at_least':
        if (!known.jobs.has(condition.jobId)) errors.push(`${owner} 引用了未知工作: ${condition.jobId}`);
        break;
      case 'owns_item':
        if (!known.items.has(condition.itemId)) errors.push(`${owner} 引用了未知商品: ${condition.itemId}`);
        break;
      case 'has_capability':
        if (!registry.vocabulary.capabilities.includes(condition.capability)) errors.push(`${owner} 引用了未知 Capability: ${condition.capability}`);
        break;
      case 'housing_is':
        if (!known.housing.has(condition.housingId)) errors.push(`${owner} 引用了未知住房: ${condition.housingId}`);
        break;
      case 'owns_business':
        if (!known.businesses.has(condition.businessId)) errors.push(`${owner} 引用了未知企业: ${condition.businessId}`);
        break;
      case 'owns_asset':
        if (!known.assets.has(condition.assetId)) errors.push(`${owner} 引用了未知资产: ${condition.assetId}`);
        break;
      case 'relationship_at_least':
      case 'relationship_stage_at_least':
        if (!known.characters.has(condition.characterId)) errors.push(`${owner} 引用了未知人物: ${condition.characterId}`);
        break;
      case 'completed_event':
        if (!known.events.has(condition.eventId)) errors.push(`${owner} 引用了未知事件: ${condition.eventId}`);
        break;
      case 'completed_milestone':
        if (!known.milestones.has(condition.milestoneId)) errors.push(`${owner} 引用了未知里程碑: ${condition.milestoneId}`);
        break;
      case 'chain_stage_at_least':
        if (!known.eventChains.has(condition.chainId)) errors.push(`${owner} 引用了未知事件链: ${condition.chainId}`);
        break;
      case 'time_between':
        if (condition.startHour < 0 || condition.startHour > 23 || condition.endHour < 0 || condition.endHour > 23) {
          errors.push(`${owner} 的时间范围无效`);
        }
        break;
      default: break;
    }
  };

  const impossibleCondition = (condition: ConditionDefinition | undefined): boolean => {
    if (!condition) return false;
    if (condition.type === 'all') {
      if (condition.conditions.some(impossibleCondition)) return true;
      const dayMins = condition.conditions.filter((child): child is Extract<ConditionDefinition, { type: 'day_at_least' }> => child.type === 'day_at_least').map((child) => child.day);
      const dayMaxes = condition.conditions.filter((child): child is Extract<ConditionDefinition, { type: 'day_at_most' }> => child.type === 'day_at_most').map((child) => child.day);
      return dayMins.length > 0 && dayMaxes.length > 0 && Math.max(...dayMins) > Math.min(...dayMaxes);
    }
    if (condition.type === 'any') return condition.conditions.length > 0 && condition.conditions.every(impossibleCondition);
    return false;
  };

  const checkModifier = (modifier: PermanentModifierDefinition, owner: string): void => {
    if (!Number.isFinite(modifier.value)) errors.push(`${owner} 的 modifier 数值无效`);
    if (modifier.mode === 'multiply' && modifier.value <= 0) errors.push(`${owner} 的乘法 modifier 必须大于 0`);
    for (const tag of modifier.tags ?? []) {
      if (!registry.vocabulary.tags.includes(tag)) errors.push(`${owner} 的 modifier 引用了未知 Tag: ${tag}`);
    }
  };

  const effectIsPositive = (effect: EffectDefinition): boolean => {
    if (effect.type === 'cash') return effect.amount > 0;
    if (effect.type === 'stat' || effect.type === 'relation') return effect.amount > 0;
    if (effect.type === 'item') return effect.quantity > 0;
    if (effect.type === 'discount') return effect.percent > 0;
    if (effect.type === 'unlock_capability' || effect.type.startsWith('unlock_') || effect.type === 'advance_chain') return true;
    if (effect.type === 'modifier') {
      return effect.modifier.mode === 'add' ? effect.modifier.value > 0 :
        (effect.modifier.target === 'work_hours' || effect.modifier.target === 'housing_rent' || effect.modifier.target === 'shop_price')
          ? effect.modifier.value < 1 : effect.modifier.value > 1;
    }
    return false;
  };

  const checkEffect = (effect: EffectDefinition, owner: string): void => {
    if (effect.type === 'item' && !known.items.has(effect.itemId)) errors.push(`${owner} 引用了未知商品: ${effect.itemId}`);
    if (effect.type === 'relation' && !known.characters.has(effect.characterId)) errors.push(`${owner} 引用了未知人物: ${effect.characterId}`);
    if (effect.type === 'unlock_job' && !known.jobs.has(effect.jobId)) errors.push(`${owner} 引用了未知工作: ${effect.jobId}`);
    if (effect.type === 'unlock_event' && !known.events.has(effect.eventId)) errors.push(`${owner} 引用了未知事件: ${effect.eventId}`);
    if (effect.type === 'unlock_housing' && !known.housing.has(effect.housingId)) errors.push(`${owner} 引用了未知住房: ${effect.housingId}`);
    if (effect.type === 'unlock_business' && !known.businesses.has(effect.businessId)) errors.push(`${owner} 引用了未知企业: ${effect.businessId}`);
    if (effect.type === 'unlock_asset' && !known.assets.has(effect.assetId)) errors.push(`${owner} 引用了未知资产: ${effect.assetId}`);
    if (effect.type === 'unlock_capability' && !registry.vocabulary.capabilities.includes(effect.capability)) errors.push(`${owner} 引用了未知 Capability: ${effect.capability}`);
    if (effect.type === 'advance_chain' && !known.eventChains.has(effect.chainId)) errors.push(`${owner} 引用了未知事件链: ${effect.chainId}`);
    if (effect.type === 'modifier') checkModifier(effect.modifier, owner);
    if (!Number.isFinite('amount' in effect ? effect.amount : 0) && effect.type !== 'modifier') errors.push(`${owner} 的 effect 数值无效`);
  };

  const checkEffects = (effects: readonly EffectDefinition[] | undefined, owner: string, requirePositive = false): void => {
    if (!effects) return;
    effects.forEach((effect) => checkEffect(effect, owner));
    if (requirePositive && !effects.some(effectIsPositive)) errors.push(`${owner} 必须包含至少一种整体正向价值`);
  };

  registry.jobs.forEach((job) => {
    if (job.hours <= 0 || job.basePay < 0 || job.careerXp < 0) errors.push(`工作 ${job.id} 的数值无效`);
    checkCondition(job.requirements, `工作 ${job.id}`);
    job.requiredItems?.forEach((id) => { if (!known.items.has(id)) errors.push(`工作 ${job.id} 引用了未知商品: ${id}`); });
    job.requiredCapabilities?.forEach((id) => { if (!registry.vocabulary.capabilities.includes(id)) errors.push(`工作 ${job.id} 引用了未知 Capability: ${id}`); });
    checkEffects(job.rewards, `工作 ${job.id}`);
    job.relatedCharacters?.forEach((id) => { if (!known.characters.has(id)) errors.push(`工作 ${job.id} 引用了未知人物: ${id}`); });
  });
  registry.items.forEach((item) => {
    if (item.price < 0 || item.resaleRatio < 0 || item.resaleRatio > 1) errors.push(`商品 ${item.id} 的价格或出售比例无效`);
    checkCondition(item.requirements, `商品 ${item.id}`); checkEffects(item.effects, `商品 ${item.id}`);
    item.capabilities?.forEach((id) => { if (!registry.vocabulary.capabilities.includes(id)) errors.push(`商品 ${item.id} 引用了未知 Capability: ${id}`); });
  });
  registry.housing.forEach((home) => { if (home.rentPerDay < 0 || home.valuation < 0 || home.furnitureCapacity < 0) errors.push(`住房 ${home.id} 的数值无效`); checkCondition(home.requirements, `住房 ${home.id}`); checkEffects(home.effects, `住房 ${home.id}`); });
  registry.businesses.forEach((business) => { if (business.price < 0 || business.priceLevels.length === 0 || business.wageLevels.length === 0 || business.inventoryLevels.length === 0) errors.push(`企业 ${business.id} 的配置无效`); checkCondition(business.requirements, `企业 ${business.id}`); checkEffects(business.effects, `企业 ${business.id}`); });
  registry.assets.forEach((asset) => { if (asset.price < 0 || asset.valuation < 0 || asset.volatility < 0) errors.push(`资产 ${asset.id} 的数值无效`); checkCondition(asset.requirements, `资产 ${asset.id}`); checkEffects(asset.effects, `资产 ${asset.id}`); });
  registry.characters.forEach((character) => { if (character.initialRelationship < 0 || character.initialRelationship > 100) errors.push(`人物 ${character.id} 的初始关系无效`); });
  registry.events.forEach((event) => {
    if (event.weight < 0 || event.cooldownDays < 0 || event.choices.length < 2) errors.push(`事件 ${event.id} 至少需要两个选项`);
    checkCondition(event.conditions, `事件 ${event.id}`);
    if (impossibleCondition(event.conditions)) errors.push(`事件 ${event.id} 完全无法触发：条件互相矛盾`);
    if (event.chain) {
      const chain = registry.eventChains.find((entry) => entry.id === event.chain?.chainId);
      if (!chain) errors.push(`事件 ${event.id} 引用了未知事件链: ${event.chain.chainId}`);
      else {
        const stage = chain.stages.find((entry) => entry.stage === event.chain?.stage);
        if (!stage) errors.push(`事件 ${event.id} 引用了事件链 ${chain.id} 中不存在的阶段`);
        else if (stage.eventId !== event.id) errors.push(`事件 ${event.id} 与事件链 ${chain.id} 的阶段映射不一致`);
      }
    }
    event.choices.forEach((choice: EventChoiceDefinition) => { checkEffects(choice.effects, `事件 ${event.id} 的选项 ${choice.id}`, true); if (choice.nextEventId && !known.events.has(choice.nextEventId)) errors.push(`事件 ${event.id} 引用了未知后续事件: ${choice.nextEventId}`); });
  });
  registry.eventChains.forEach((chain) => {
    if (chain.stages.length === 0) errors.push(`事件链 ${chain.id} 不能为空`);
    chain.stages.forEach((stage) => { if (!known.events.has(stage.eventId)) errors.push(`事件链 ${chain.id} 引用了未知事件: ${stage.eventId}`); checkCondition(stage.conditions, `事件链 ${chain.id} 阶段 ${stage.stage}`); });
  });
  registry.milestones.forEach((milestone) => { checkCondition(milestone.condition, `里程碑 ${milestone.id}`); checkEffects(milestone.effects, `里程碑 ${milestone.id}`); });

  return { valid: errors.length === 0, errors };
}
