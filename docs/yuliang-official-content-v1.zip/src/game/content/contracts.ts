import type { GameTime } from '../engine/time';

export type ContentStatus = 'seed' | 'official';
export type ContentId = string;
export type ContentTag = string;
export type CapabilityId = string;
export type RewardTier = 'small' | 'normal' | 'large' | 'milestone';
export type StatName = 'ability' | 'reputation' | 'lifestyle';
export type PlayerStage = 'start' | 'growing' | 'stable' | 'wealthy';

export interface ContentMeta {
  id: ContentId;
  contentStatus: ContentStatus;
  name: string;
  description: string;
  tags?: readonly ContentTag[];
}

export type ConditionDefinition =
  | { type: 'all'; conditions: readonly ConditionDefinition[] }
  | { type: 'any'; conditions: readonly ConditionDefinition[] }
  | { type: 'not'; condition: ConditionDefinition }
  | { type: 'day_at_least'; day: number }
  | { type: 'day_at_most'; day: number }
  | { type: 'time_between'; startHour: number; endHour: number }
  | { type: 'player_stage'; stage: PlayerStage }
  | { type: 'cash_at_least'; amount: number }
  | { type: 'ability_at_least'; amount: number }
  | { type: 'reputation_at_least'; amount: number }
  | { type: 'lifestyle_at_least'; amount: number }
  | { type: 'current_job'; jobId: ContentId }
  | { type: 'job_experience_at_least'; jobId: ContentId; amount: number }
  | { type: 'owns_item'; itemId: ContentId; quantity?: number }
  | { type: 'has_capability'; capability: CapabilityId }
  | { type: 'housing_is'; housingId: ContentId; mode?: 'rent' | 'owned' }
  | { type: 'owns_business'; businessId: ContentId }
  | { type: 'owns_asset'; assetId: ContentId }
  | { type: 'relationship_at_least'; characterId: ContentId; amount: number }
  | { type: 'relationship_stage_at_least'; characterId: ContentId; stage: number }
  | { type: 'completed_event'; eventId: ContentId }
  | { type: 'completed_milestone'; milestoneId: ContentId }
  | { type: 'chain_stage_at_least'; chainId: ContentId; stage: number }
  | { type: 'flag'; flag: string };

export interface PermanentModifierDefinition {
  target: 'work_pay' | 'work_hours' | 'study_gain' | 'business_profit' | 'housing_rent' | 'shop_price' | 'event_reward';
  mode: 'add' | 'multiply';
  value: number;
  tags?: readonly ContentTag[];
}

export type EffectDefinition =
  | { type: 'cash'; amount: number; rewardTier?: RewardTier }
  | { type: 'stat'; stat: StatName; amount: number }
  | { type: 'relation'; characterId: ContentId; amount: number }
  | { type: 'item'; itemId: ContentId; quantity: number }
  | { type: 'unlock_capability'; capability: CapabilityId }
  | { type: 'unlock_job'; jobId: ContentId }
  | { type: 'unlock_event'; eventId: ContentId }
  | { type: 'unlock_housing'; housingId: ContentId }
  | { type: 'unlock_business'; businessId: ContentId }
  | { type: 'unlock_asset'; assetId: ContentId }
  | { type: 'discount'; percent: number; tags?: readonly ContentTag[] }
  | { type: 'modifier'; modifier: PermanentModifierDefinition }
  | { type: 'advance_time'; hours: number }
  | { type: 'set_flag'; flag: string }
  | { type: 'advance_chain'; chainId: ContentId; stage: number };

export interface JobDefinition extends ContentMeta {
  kind: 'regular' | 'temporary' | 'freelance';
  hours: number;
  basePay: number;
  abilityRequired?: number;
  reputationRequired?: number;
  requirements?: ConditionDefinition;
  requiredItems?: readonly ContentId[];
  requiredCapabilities?: readonly CapabilityId[];
  careerXp: number;
  rewards?: readonly EffectDefinition[];
  relatedCharacters?: readonly ContentId[];
  isLongTerm: boolean;
}

export type ItemCategory = 'consumable' | 'technology' | 'clothing' | 'furniture' | 'entertainment' | 'luxury' | 'collectible';

export interface ItemDefinition extends ContentMeta {
  category: ItemCategory;
  price: number;
  consumable: boolean;
  sellable: boolean;
  resaleRatio: number;
  lifestyleDelta: number;
  capabilities?: readonly CapabilityId[];
  statEffects?: Partial<Record<StatName, number>>;
  requirements?: ConditionDefinition;
  housingTags?: readonly ContentTag[];
  effects?: readonly EffectDefinition[];
}

export interface HousingDefinition extends ContentMeta {
  mode: 'rent' | 'buy' | 'both';
  rentPerDay: number;
  price?: number;
  valuation: number;
  lifestyleDelta: number;
  furnitureCapacity: number;
  requirements?: ConditionDefinition;
  effects?: readonly EffectDefinition[];
}

export interface BusinessDefinition extends ContentMeta {
  price: number;
  baseRevenue: number;
  baseGoodsCost: number;
  baseWage: number;
  baseRent: number;
  priceLevels: readonly number[];
  wageLevels: readonly number[];
  inventoryLevels: readonly number[];
  requirements?: ConditionDefinition;
  effects?: readonly EffectDefinition[];
}

export interface AssetDefinition extends ContentMeta {
  kind: 'investment' | 'rental' | 'collectible';
  price: number;
  valuation: number;
  dailyIncome: number;
  volatility: number;
  requirements?: ConditionDefinition;
  effects?: readonly EffectDefinition[];
}

export interface RelationshipStageDefinition {
  threshold: number;
  label: string;
  effects?: readonly EffectDefinition[];
  unlockEventIds?: readonly ContentId[];
}

export interface CharacterDefinition extends ContentMeta {
  identity: string;
  initialRelationship: number;
  stages: readonly RelationshipStageDefinition[];
}

export interface EventChoiceDefinition {
  id: string;
  text: string;
  effects: readonly EffectDefinition[];
  nextEventId?: ContentId;
  nextChainStage?: { chainId: ContentId; stage: number };
}

export interface EventDefinition extends ContentMeta {
  title: string;
  body: string;
  category: 'work' | 'career' | 'shopping' | 'housing' | 'relationship' | 'business' | 'investment' | 'asset' | 'life' | 'luck';
  weight: number;
  cooldownDays: number;
  conditions?: ConditionDefinition;
  timeRange?: { startHour: number; endHour: number };
  playerStages?: readonly PlayerStage[];
  choices: readonly EventChoiceDefinition[];
  chain?: { chainId: ContentId; stage: number };
}

export interface EventChainStageDefinition {
  stage: number;
  eventId: ContentId;
  waitDays?: number;
  conditions?: ConditionDefinition;
}

export interface EventChainDefinition extends ContentMeta {
  stages: readonly EventChainStageDefinition[];
}

export interface MilestoneDefinition extends ContentMeta {
  condition: ConditionDefinition;
  effects?: readonly EffectDefinition[];
}

export interface VocabularyDefinition {
  capabilities: readonly CapabilityId[];
  tags: readonly ContentTag[];
}

export interface ContentRegistry {
  jobs: readonly JobDefinition[];
  items: readonly ItemDefinition[];
  housing: readonly HousingDefinition[];
  businesses: readonly BusinessDefinition[];
  assets: readonly AssetDefinition[];
  characters: readonly CharacterDefinition[];
  events: readonly EventDefinition[];
  eventChains: readonly EventChainDefinition[];
  milestones: readonly MilestoneDefinition[];
  vocabulary: VocabularyDefinition;
}

export interface BusinessHolding {
  businessId: ContentId;
  priceLevel: number;
  wageLevel: number;
  inventoryLevel: number;
  purchasePrice: number;
}

export interface AssetHolding {
  assetId: ContentId;
  purchasePrice: number;
  purchaseDay: number;
  currentValuation: number;
}

export interface HousingState {
  housingId: ContentId;
  mode: 'rent' | 'owned';
}

export interface RngState {
  seed: number;
  cursor: number;
}

export interface GameState {
  version: number;
  contentVersion: number;
  time: GameTime;
  cash: number;
  ability: number;
  reputation: number;
  lifestyle: number;
  currentJobId?: ContentId;
  jobExperience: Record<ContentId, number>;
  inventory: Record<ContentId, number>;
  itemPurchasePrices: Record<ContentId, number>;
  unlockedCapabilities: CapabilityId[];
  unlockedJobIds: ContentId[];
  unlockedHousingIds: ContentId[];
  unlockedBusinessIds: ContentId[];
  unlockedAssetIds: ContentId[];
  housing: HousingState;
  relationships: Record<ContentId, number>;
  businesses: Record<ContentId, BusinessHolding>;
  assets: Record<ContentId, AssetHolding>;
  completedEvents: ContentId[];
  completedMilestones: ContentId[];
  eventCooldowns: Record<ContentId, number>;
  chainStages: Record<ContentId, number>;
  flags: Record<string, boolean>;
  modifiers: PermanentModifierDefinition[];
  discounts: Array<{ percent: number; tags: string[]; expiresDay?: number }>;
  marketJobIds: ContentId[];
  pendingEventId?: ContentId;
  eventMeter: number;
  eventDay: number;
  eventsToday: number;
  lastSettledDay: number;
  rentReliefAvailableDay: number;
  housingReliefUntilDay: number;
  rng: RngState;
}

export type GameAction =
  | { type: 'work'; jobId: ContentId }
  | { type: 'study' }
  | { type: 'rest' }
  | { type: 'accept_job'; jobId: ContentId }
  | { type: 'purchase_items'; items: Record<ContentId, number> }
  | { type: 'sell_item'; itemId: ContentId; quantity: number }
  | { type: 'move_housing'; housingId: ContentId; mode: 'rent' | 'owned' }
  | { type: 'buy_business'; businessId: ContentId }
  | { type: 'update_business'; businessId: ContentId; priceLevel: number; wageLevel: number; inventoryLevel: number }
  | { type: 'buy_asset'; assetId: ContentId }
  | { type: 'sell_asset'; assetId: ContentId }
  | { type: 'choose_event'; eventId: ContentId; choiceId: string }
  | { type: 'set_flag'; flag: string; value: boolean };

export type GameEffect =
  | { type: 'time'; from: GameTime; to: GameTime; hours: number }
  | { type: 'cash'; amount: number; reason: string }
  | { type: 'stat'; stat: StatName; amount: number }
  | { type: 'relation'; characterId: ContentId; amount: number }
  | { type: 'unlock'; kind: string; id: string }
  | { type: 'purchase'; itemId: ContentId; quantity: number; total: number }
  | { type: 'settlement'; day: number; cashDelta: number; details: readonly SettlementDetail[] }
  | { type: 'event'; eventId: ContentId }
  | { type: 'milestone'; milestoneId: ContentId }
  | { type: 'message'; text: string };

export interface SettlementDetail {
  label: string;
  amount: number;
}

export interface GameResult {
  state: GameState;
  effects: GameEffect[];
  error?: string;
}
