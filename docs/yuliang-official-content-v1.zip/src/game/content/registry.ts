import type { ContentRegistry } from './contracts';
import { officialContent } from './official';
import { seedContent } from './seed';

function preferOfficial<T>(official: readonly T[], seed: readonly T[]): readonly T[] {
  if (official.length === 0) return seed;
  const byId = new Map(seed.map((entry) => [(entry as { id: string }).id, entry]));
  official.forEach((entry) => byId.set((entry as { id: string }).id, entry));
  return [...byId.values()];
}

export const contentRegistry: ContentRegistry = {
  jobs: preferOfficial(officialContent.jobs, seedContent.jobs),
  items: preferOfficial(officialContent.items, seedContent.items),
  housing: preferOfficial(officialContent.housing, seedContent.housing),
  businesses: preferOfficial(officialContent.businesses, seedContent.businesses),
  assets: preferOfficial(officialContent.assets, seedContent.assets),
  characters: preferOfficial(officialContent.characters, seedContent.characters),
  events: preferOfficial(officialContent.events, seedContent.events),
  eventChains: preferOfficial(officialContent.eventChains, seedContent.eventChains),
  milestones: preferOfficial(officialContent.milestones, seedContent.milestones),
  vocabulary: seedContent.vocabulary,
};

export function composeContentRegistry(overrides: Partial<ContentRegistry> = {}): ContentRegistry {
  return {
    jobs: preferOfficial(overrides.jobs ?? [], seedContent.jobs),
    items: preferOfficial(overrides.items ?? [], seedContent.items),
    housing: preferOfficial(overrides.housing ?? [], seedContent.housing),
    businesses: preferOfficial(overrides.businesses ?? [], seedContent.businesses),
    assets: preferOfficial(overrides.assets ?? [], seedContent.assets),
    characters: preferOfficial(overrides.characters ?? [], seedContent.characters),
    events: preferOfficial(overrides.events ?? [], seedContent.events),
    eventChains: preferOfficial(overrides.eventChains ?? [], seedContent.eventChains),
    milestones: preferOfficial(overrides.milestones ?? [], seedContent.milestones),
    vocabulary: overrides.vocabulary ?? contentRegistry.vocabulary,
  };
}
