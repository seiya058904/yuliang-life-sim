import type { VocabularyDefinition } from './contracts';

export const vocabulary: VocabularyDefinition = {
  capabilities: ['remote_work', 'home_workspace', 'business_license', 'market_insight'],
  tags: ['work', 'office', 'remote', 'starter', 'technology', 'clothing', 'furniture', 'luxury', 'collectible', 'housing', 'business', 'asset', 'relationship', 'life', 'luck', 'career', 'shopping'],
};
