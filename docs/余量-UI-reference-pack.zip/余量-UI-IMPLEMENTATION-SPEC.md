# UI IMPLEMENTATION SPEC

## 1. Executive Summary

本规格用于把《余量》现有网页 UI 统一重构为四张概念图所定义的视觉系统，并要求 Coding Agent 在现有 React + Vite + TypeScript + Zustand 项目中进行真实、可交互、可响应、可维护的 UI 实现，而不是把截图当作背景图或做静态假页面。

四张参考图属于 **Same product — different page**：

1. `01-life-main.png`：生活 / 自动运行主循环
2. `02-career-market.png`：职业 / 招聘市场
3. `03-shop-life.png`：商店 / 生活消费与活动
4. `04-month-settlement.png`：月结算 / 月度回顾

四图共同定义《余量》的统一视觉语言：

- 黑 / 白 / 灰的高对比单色界面；
- 明显的 1-bit / 像素游戏 UI 语言；
- 高信息密度，但必须保持强层级和高可读性；
- 直角、细线、像素边框、块状按钮、段式进度条；
- 游戏 HUD / 模拟经营界面，而不是 SaaS Dashboard、招聘网站或财务后台；
- 页面状态必须“一眼可读”：当前 Tab、当前活动、可执行按钮、禁用状态、申请状态、结算结果都要明显；
- 视觉风格统一，但各页保留不同的信息结构；
- 真实游戏数据、状态与业务语义仍以现有仓库和产品设计文档为准，概念图中的示例数字和示例文案不得硬编码为游戏事实。

最不能出错的地方：

1. 不要仅仅把现有白底页面换成黑底；必须重构信息层级、卡片语言、按钮语言和页面节奏。
2. 不要把整个页面绝对定位成截图坐标。
3. 不要为了“像素风”牺牲中文可读性。
4. 不要把概念图中的示例内容误当成新的业务规则。
5. 四个页面必须像同一个游戏，而不是四套独立主题。
6. 月结算必须遵守《余量》既有财务语义，并且**不得加入对玩家人生进行评分或等级评价的机制**。

---

## 2. Source & Canvas

### Source files

| File | Page | Source size | Classification |
|---|---|---:|---|
| `01-life-main.png` | 生活 / 主循环 | 1448 × 1086 | OBSERVED |
| `02-career-market.png` | 职业 / 招聘市场 | 1448 × 1086 | OBSERVED |
| `03-shop-life.png` | 商店 / 生活消费 | 1448 × 1086 | OBSERVED |
| `04-month-settlement.png` | 月结算 | 1448 × 1086 | OBSERVED |

### Device class

- Desktop / Landscape — **OBSERVED**
- Browser Chrome 未显示 — **OBSERVED**
- Device Frame 未显示 — **OBSERVED**
- 四图均为完整产品界面概念稿，而非长网页滚动截面 — **OBSERVED**

### Likely implementation viewport

- 参考视觉宽度：`~1440px` — **ESTIMATED**
- 建议主要桌面校正区间：`1366–1536px`
- 概念图像素尺寸不能直接等同于 CSS viewport；实现应使用 Grid / Flex / relative sizing，而不是以 1448 × 1086 为硬编码布局。

### Crop / scrolling clues

- 概念图主体均在一个完整桌面画布内呈现。
- 未观察到浏览器滚动条。
- 是否允许页面纵向滚动取决于真实内容量与项目现状，概念图本身不能证明固定高度页面。  
  **INFERRED — confidence: medium**

---

## 3. Page Structure

### 3.1 Shared Shell

```text
AppShell
├── TopStatusBar
│   ├── BrandBlock
│   │   ├── GameTitle "余量"
│   │   ├── Subtitle "人生模拟"
│   │   └── Optional small pixel mark / mascot
│   ├── DateBlock
│   ├── TimeBlock
│   ├── CashMetric
│   ├── NetWorthMetric
│   └── SettingsAction
├── PrimaryNavigation
│   ├── 生活
│   ├── 职业
│   ├── 商店
│   ├── 财务
│   ├── 社交
│   ├── 城市
│   └── 我的
├── PageContent
└── Optional PersistentStatusBar
    ├── Character / profile mark
    ├── Attribute meters
    └── 属性详情
```

### 3.2 生活 / 主循环

```text
LifePage
├── ActivityHeroRow
│   ├── CurrentTimePanel
│   ├── CurrentActivityPanel
│   ├── SpeedAndRunControls
│   └── WeeklyForecastPanel
├── WeeklyPlanner
│   ├── WeekHeader
│   ├── DayColumns × 7
│   └── DaypartRows
├── InboxGrid
│   ├── 待处理事项
│   ├── 消息
│   ├── 事件
│   └── Offer / 机会
└── PersistentStatusBar
```

### 3.3 职业 / 招聘市场

```text
CareerMarketPage
├── CareerSidebar
│   ├── Search
│   ├── OpportunityTypeFilters
│   └── IndustryFilters
├── CareerMain
│   ├── TopFilterToolbar
│   ├── JobCardGrid
│   └── Pagination
├── JobDetailPanel
│   ├── JobSummary
│   ├── Requirements
│   ├── PlayerMatch
│   ├── AcquisitionHints
│   ├── RecruitmentFlow
│   ├── Recruiter
│   └── ApplyCTA
├── CareerBottomPanels
│   ├── 我的申请
│   ├── Offer
│   ├── 职业履历
│   └── 市场洞察
└── PersistentStatusBar
```

### 3.4 商店 / 生活消费

```text
ShopLifePage
├── CategoryToolbar
│   ├── 商品
│   ├── 服务
│   ├── 娱乐
│   ├── 学习
│   ├── 社交
│   └── 旅行
├── MainCatalog
│   ├── ProductCardGrid
│   ├── Pagination
│   └── SelectedItemDetail
├── RightSidebar
│   ├── 购物清单
│   ├── 本周安排
│   ├── 已拥有
│   └── 愿望清单
└── PersistentStatusBar
```

### 3.5 月结算

```text
MonthSettlement
├── SettlementHeader
│   ├── MonthLabel
│   ├── DateRange
│   └── ShortReflectionCopy
├── FinanceSummaryGrid
│   ├── IncomePanel
│   ├── ExpensePanel
│   ├── AssetChangePanel
│   └── NetWorthPanel
├── SecondaryFinanceCards
│   ├── RealizedGain
│   └── AssetLiquidation
├── MonthlyHighlights
│   └── HighlightCard × N
├── NeutralMonthlyReflection
└── ContinueCTA
```

**Important semantic correction**

`04-month-settlement.png` 中存在一个视觉上类似 “本月评价 / S” 的卡片。  
这只是概念图中的视觉占位，不应成为正式产品机制。

《余量》的 canonical 设计明确要求：

- 不给人生打分；
- 不做年度 / 月度等级；
- 不评价玩家路线“优秀 / 落后”；
- 只记录事实与变化。

因此实现时：

- **保留该卡片的视觉权重与位置**
- **替换为中性内容**，例如：
  - `本月回顾`
  - `本月变化`
  - `值得记住`
  - `本月里程碑`
- 不显示 `S/A/B/C` 等等级。

---

## 4. Spatial & Layout Map

### 4.1 Shared AppShell

#### TopStatusBar

- Position: viewport top — **OBSERVED**
- Width: full width
- Height: `~80–92px` including nav — **ESTIMATED**
- Background: near-black
- Border bottom: 1px light gray / white
- Layout: flex-row
- Brand occupies left `~24–28%`
- Date/time and finance metrics occupy center/right
- Internal padding: `~16–28px`

#### PrimaryNavigation

- Directly below status row — **OBSERVED**
- Horizontal tab row
- Selected tab uses inverted treatment:
  - light/white background
  - dark text
- Unselected:
  - black background
  - white/light text
- Tabs should not use rounded SaaS pills.

### 4.2 生活 page

Reference proportions:

```text
Main content width
├── Activity area ~78%
└── Weekly forecast ~22%
```

Activity area itself:

```text
Current time ~34%
Current activity ~42%
Run controls ~24%
```

Weekly planner:

- Full-width major band under activity row.
- 7 equal day columns.
- Daypart rows share a fixed left label column.
- High contrast cell borders.
- Repetition should feel like a game board, not a data table.

Lower inbox:

- 4 equal or near-equal panels.
- Horizontal grid.
- Short summaries only.
- Each panel ends with a clear secondary action.

### 4.3 职业 page

Reference composition:

```text
Career body
├── Left filter sidebar ~17%
├── Job grid ~53%
└── Job detail ~30%
```

- Sidebar and detail panel have stronger outer borders.
- Center job cards use a 3-column grid in the reference.
- On narrower desktop widths, 2-column cards are acceptable if proportions remain readable.  
  **INFERRED — confidence: high**

Bottom panels:

- 4 columns of supporting information.
- Lower visual priority than job market + selected detail.

### 4.4 商店 page

Reference composition:

```text
Shop body
├── Catalog ~76%
└── Utility sidebar ~24%
```

Catalog:

- 3-column card grid.
- Cards repeat a strong fixed pattern.
- Selected-item detail spans width below grid.

Right sidebar:

- stacked vertically:
  - cart
  - weekly schedule
  - owned items
  - wishlist

### 4.5 月结算

- Full content uses a single large framed settlement composition.
- Main heading is centered and is the first focal point.
- Financial summary uses approximately 4 main columns.
- Net-worth panel has the strongest visual emphasis among summary cards.
- Monthly highlights form a horizontal row below.
- Continue CTA sits bottom-right and is visually dominant.

---

## 5. Design System

### Colors

All color values are **ESTIMATED** from concept screenshots.

```text
--ui-bg:                ~#050505
--ui-surface:           ~#0A0A0A
--ui-surface-raised:    ~#111111
--ui-surface-muted:     ~#1C1C1C

--ui-text-primary:      ~#F7F7F4
--ui-text-secondary:    ~#C8C8C4
--ui-text-muted:        ~#8E8E89
--ui-text-inverse:      ~#0A0A0A

--ui-border-strong:     ~#F0F0EC
--ui-border:            ~#A9A9A5
--ui-divider:           ~#4A4A47

--ui-fill-primary:      ~#F4F4F0
--ui-fill-secondary:    ~#A8A8A3
--ui-fill-dark:         ~#242422
```

No saturated brand color is observed.

Status semantics must primarily use:

- fill pattern
- border weight
- inversion
- icon
- label text

rather than red / green / orange.

This is important for preserving the 1-bit identity.

### Typography

Exact font family: `Unknown`.

Observed:

- pixel / bitmap-like display appearance
- high contrast
- monospaced or near-monospaced rhythm in numeric UI
- Chinese text remains compact and legible

Implementation guidance:

```text
Display XL: ~54–72px / 700–800 / line-height ~1.0
Display:    ~38–48px / 700–800 / ~1.05
H1:         ~28–34px / 700
H2:         ~20–24px / 700
H3:         ~16–18px / 700
Body:       ~13–15px / 400–500 / ~1.35–1.5
Body Small: ~11–13px / 400
Label:      ~11–13px / 600–700
Button:     ~13–16px / 600–700
Metric:     numeric emphasis, tabular/monospace preferred
```

Implementation rule:

- If the project already contains a Chinese-capable pixel font, reuse it.
- Otherwise use a highly legible CJK sans/monospace fallback and reproduce the pixel feel through layout, border, iconography and display typography.
- Do not use an unreadable Latin-only pixel font for Chinese.
- Do not identify or import a specific font solely from guessing the screenshot.

### Spacing

Primary spacing rhythm:

```text
2 / 4 / 8 / 12 / 16 / 24 / 32px
```

- Dense internal controls: 4–8px
- Card internals: 8–12px
- Panel padding: 12–16px
- Major region gaps: 16–24px

Avoid large “marketing website” whitespace.

### Radius

Observed visual system is predominantly square.

```text
radius-none: 0
radius-xs:   ~1–2px
radius-sm:   ~2–4px only where needed for usability
```

Avoid:

- 12px+ cards
- rounded SaaS containers
- pill-heavy interfaces

### Borders

Core identity.

```text
standard border: 1px
strong panel border: 1–2px
active / selected border: 2px or inverted fill
decorative dotted divider: 1px dotted
```

Use repeated border language consistently.

### Shadows

- No meaningful soft drop shadows observed.
- Prefer flat / bordered surfaces.
- If focus separation is required, use border + fill inversion instead of blur shadows.

### Density

- High density — **OBSERVED**
- Compact but not cramped.
- UI should display more useful state per viewport than current implementation.
- Density must be achieved through grid structure and typography discipline, not tiny illegible text.

---

## 6. Section Specifications

### 6.1 Shared TopStatusBar

**Purpose**

Persistent game-state identity and orientation.

**Visible information**

- `余量`
- `人生模拟`
- current week / weekday
- date
- current time
- cash
- net worth
- settings

**Layout**

- horizontal flex
- vertically centered
- bordered metric groups
- large title on left
- finance metrics right-aligned

**Visual notes**

- Title has much higher visual weight than subtitle.
- Current time is displayed as a contained digital readout.
- Finance metrics are icon + label + large number.
- Do not place everything in soft cards.

---

### 6.2 Primary Navigation

**Purpose**

Primary IA navigation.

**Observed tabs**

- 生活
- 职业
- 商店
- 财务
- 社交
- 城市
- 我的

**Current state**

One active tab shown with inversion.

**Implementation**

- Use semantic navigation.
- Selected state must be obvious without relying on subtle color shifts.
- Use pixel-style icons or simple monochrome SVGs.
- Do not use Emoji.

---

### 6.3 Life — Current Activity Hero

**Purpose**

Make the simulation loop visually dominant.

**CurrentTimePanel**

- huge `08:00` style numeric display
- weekday / week under it
- optional small time-of-day icon

**CurrentActivityPanel**

- label `当前活动`
- large activity name
- activity time range
- short description
- segmented progress bar
- `下一活动` line

**RunControls**

- speed buttons `x1 / x2 / x4`
- one selected state
- primary run button
- pause button
- active/disabled states visually unmistakable

**Required implementation behavior**

- Real simulation state drives all values.
- Progress animation is view-only.
- Starting/pausing must use existing game actions.
- No UI animation may mutate domain state.

---

### 6.4 Life — Weekly Forecast

**Purpose**

Show expected weekly outcome before running.

**Visible categories**

- 预计收入
- 预计支出
- 现金净变化
- 属性变化

Attribute changes use segmented bars / compact meters.

**Design**

- white/light surface inside dark shell is acceptable, as shown.
- contrast is used to create strong hierarchy.
- should not become a full spreadsheet.

---

### 6.5 Life — Weekly Planner

**Purpose**

Make planning visually understandable in one glance.

**Structure**

- 7 day columns
- day header + date
- at least 2 dayparts in concept
- icon + activity name + time range

**State treatment**

- work / study / social / life / free / other differentiated primarily by icon and label.
- Keep monochrome identity.
- Avoid using rainbow calendar colors.

**Interaction**

- Existing planner behavior is source of truth.
- Cell selection / editing states are **INFERRED**.
- If current app supports richer planner periods, preserve those semantics while keeping this visual language.

---

### 6.6 Life — Inbox Grid

Four panels:

- 待处理事项
- 消息
- 事件
- Offer / 机会

Each panel:

- icon + title + count badge
- 2–4 compact rows
- optional date/deadline
- one footer action

Do not show every message in the home screen.

---

### 6.7 Career — Filter Sidebar

**Purpose**

Fast narrowing of the market.

**Observed controls**

- search input
- opportunity type groups
- category/industry groups
- counts

**Visual**

- dark panel
- selected row uses white inversion
- counts right aligned
- no soft gray accordion styling

---

### 6.8 Career — JobCard

Reusable pattern.

**Card anatomy**

```text
JobCard
├── optional category/status marker
├── title
├── company
├── pay
├── type
├── location
├── short description
└── footer
    ├── status
    └── action
```

**Observed states**

- 可申请
- 缺少条件
- 已申请
- 推荐机会

**State design**

- selected / recommended card may use stronger border.
- action buttons must not all look identical when disabled or unavailable.
- no hidden click-only affordance.

---

### 6.9 Career — JobDetailPanel

**Purpose**

The detail pane is the decision surface.

**Sections**

- title + company
- pay / type / location / duration / publish time
- requirements
- missing conditions
- how to improve / AcquisitionHint
- current condition comparison
- recruitment flow
- recruiter
- match summary
- primary application CTA

**Critical rule**

Requirements must bind to real domain conditions and explanations.

Do not create visual-only fake percentages if current engine does not provide them.

If the game uses qualitative competitiveness rather than exact percentages, keep the screenshot’s bar/comparison visual form but show the real canonical wording.

---

### 6.10 Career — Supporting Panels

- 我的申请
- Offer
- 职业履历
- 市场洞察

These should remain secondary.

`市场洞察` must not invent simulation facts.
Only show metrics actually available in domain state/content.

---

### 6.11 Shop — Category Toolbar

Observed top categories:

- 商品
- 服务
- 娱乐
- 学习
- 社交
- 旅行

Use segmented rectangular controls.

Selected category:

- light fill
- dark text
- strong border

---

### 6.12 Shop — Catalog Card

Reusable for item / service / activity-like content.

**Card anatomy**

```text
CatalogCard
├── category tag
├── title
├── price
├── pixel icon
├── time
├── effect
├── requirement
├── financial category
└── action
```

Card text must be sourced from actual content definitions.

Not every card needs permanent stat effects.
If real content has no effect, show appropriate neutral information rather than inventing stats.

---

### 6.13 Shop — Utility Sidebar

Stacked panels.

#### 购物清单

- item rows
- price
- remove action
- estimated total
- purchase CTA

#### 本周安排

- scheduled activities
- weekday / time / activity
- compact icons

#### 已拥有

- compact icon strip / small grid
- count
- link to inventory

#### 愿望清单

- saved item
- price
- clear list hierarchy

---

### 6.14 Shop — Selected Item Detail

Bottom horizontal panel.

Show:

- selected item icon
- name
- price
- short description
- attribute/effect changes if any
- relationship change if any
- financial category
- time cost / schedulability

This panel should explain consequences before player commits.

---

### 6.15 Month Settlement — Header

**Primary focal point**

Large:

`第 N 月结算`

Supporting:

- date range
- month days
- neutral short reflection line

Avoid congratulatory language that evaluates lifestyle quality.

Good examples:

- `这一月发生了这些变化`
- `时间继续向前，本月记录如下`

---

### 6.16 Month Settlement — Finance Grid

#### IncomePanel

Examples of supported rows:

- 工资
- 兼职
- 分红
- 租金
- 业务收入

Only categories that actually exist in ledger should appear.

#### ExpensePanel

Examples:

- 住房
- 基础生活
- 活动消费
- 购物
- 交通
- 订阅

#### AssetChangePanel

Must not conflate:

- asset allocation
- valuation change
- liquidation
- realized gain/loss

#### NetWorthPanel

Highest-weight finance card.

Show:

- previous net worth
- current net worth
- absolute change
- optional percentage change if meaningful

This is a summary, not a score.

---

### 6.17 Month Settlement — Secondary Finance Cards

Separate cards for:

- 已实现收益
- 资产变现

If canonical ledger exposes these separately, preserve that distinction visually.

Principal returned from liquidation must not be reported as income.

---

### 6.18 Month Settlement — Monthly Highlights

Horizontal cards such as:

- 新工作
- 新联系人
- 新资格
- 新房产
- 新投资机会
- 其他人生记录

These cards are data-driven.

Do not guarantee all cards appear every month.

If nothing major happened, fewer cards or a quieter reflection is correct.

---

### 6.19 Month Settlement — Continue CTA

Primary action:

`进入下月` or canonical equivalent.

Large, high-contrast, bottom-right.

Must clearly communicate whether game resumes immediately or returns paused according to current product behavior.

---

## 7. Component Specifications

### Component: `PixelPanel`

Type: container  
Location: all pages  
Approximate dimensions: variable  
Layout: flex/grid child container  
Background: dark or inverted light surface  
Border: 1px / occasionally 2px  
Radius: 0–2px  
Shadow: none  
Current state: standard / selected / emphasized  
Implementation notes:

- base reusable primitive
- optional title row
- optional dotted separator
- optional pixel-corner decoration
- no ornamental complexity that harms readability

Confidence: high

---

### Component: `PixelButton`

Type: button

Variants:

```text
primary
secondary
selected
disabled
dangerous-action-if-existing
icon-only
```

Observed primary:

- white/light fill
- black text
- strong rectangular outline

Observed secondary:

- dark fill
- light text
- 1px border

Disabled:

- lower contrast
- must remain identifiable as disabled

Hover / focus:

- **INFERRED — confidence: high**
- use border inversion / fill inversion / 1px offset
- no large glow
- keyboard focus must remain accessible

---

### Component: `PixelTab`

- rectangular
- dense horizontal group
- selected by inversion
- optional monochrome icon
- no large pill radius

---

### Component: `SegmentMeter`

Used for:

- attributes
- job requirement comparison
- progress
- small status meters

Appearance:

- sequence of small square/rectangular blocks
- filled vs unfilled
- high contrast

Do not use smooth colorful gradient bars.

---

### Component: `MetricBlock`

Used for:

- cash
- net worth
- income
- expenses
- net change

Structure:

```text
icon
label
large numeric value
optional supporting text
```

Numbers should use tabular alignment where possible.

---

### Component: `PixelIcon`

- monochrome
- simple 1-bit silhouette
- square grid appearance
- consistent optical size

Implementation:

- SVG sprite / reusable component preferred
- CSS reconstruction acceptable for trivial shapes
- Emoji prohibited

---

### Component: `StatusBadge`

Examples:

- 可申请
- 已申请
- 缺少条件
- 推荐
- NEW

Use:

- outline
- inverted small label
- corner ribbon where visually appropriate

Do not rely on color alone.

---

### Component: `PixelCard`

Shared structural family for:

- job cards
- shop cards
- highlight cards

Common rules:

- 1px strong border
- square geometry
- 8–12px internal padding
- clear header/body/footer
- content aligned to grid
- action separated from descriptive text

Do not force all cards to identical height if content would become clipped, but maintain row consistency where possible.

---

### Component: `PersistentStatusBar`

Observed at bottom of the three non-modal pages and month settlement.

Contains:

- compact avatar / identity icon
- attribute labels
- segmented meters
- current numeric value
- 属性详情 action

If the current canonical game uses a different attribute set, bind this component to real attributes rather than reproducing mockup-only labels.

---

## 8. Content & Text

### Shared visible labels

```text
余量
人生模拟

生活
职业
商店
财务
社交
城市
我的

现金
净资产
```

### Life concepts visible in reference

```text
当前时间
当前活动
基础生活
进度
下一活动
时间速度
开始本周
暂停
本周预测
预计收入
预计支出
现金净变化
属性变化
本周计划
待处理事项
消息
事件
Offer
```

### Career concepts visible in reference

```text
招聘市场
搜索岗位 / 公司 / 关键词
正式岗位
长期兼职
Gig
推荐机会
猎头机会
申请岗位
查看要求
查看进度
岗位详情
任职要求
缺少条件
如何达标
当前条件对比
招聘流程
招聘人
我的申请
Offer
职业履历
市场洞察
```

### Shop concepts visible in reference

```text
商品
服务
娱乐
学习
社交
旅行
购物清单
结算购买
本周安排
已拥有
愿望清单
属性变化
关系变化
支出分类
时间消耗
```

### Settlement concepts visible in reference

```text
第 N 月结算
收入
支出
资产配置
净资产变化
已实现收益
资产变现
本月重要收获
进入下月
```

### Important content rule

The screenshots contain sample jobs, sample products, sample numbers and illustrative game state.

These are **visual examples**, not canonical content.

Implementation must:

1. preserve labels that represent real UI concepts;
2. source job/product/activity/company/player values from actual state/content;
3. never hardcode screenshot-specific money values or dates;
4. never invent new game systems merely because a decorative mock value appears in an image.

---

## 9. Assets

### Brand title

Asset type: text treatment  
Importance: critical  
Recommended implementation:

- real text, not raster image
- large high-weight Chinese title
- preserve pixel/retro identity

### Mascot / small pixel face

Asset type: decorative / identity mark  
Importance: medium  
Observed on several screenshots.

Whether the cat/character icon becomes a permanent product asset is not proven by the original game.  
Treat as optional visual motif unless already accepted in the product.

**INFERRED — confidence: medium**

### Functional icons

Required categories include:

- home
- briefcase / career
- cart / shop
- finance chart
- social / people
- city/building
- profile
- cash
- net worth
- calendar
- clock
- settings
- work
- study/book
- social
- free time/game
- message
- event
- offer
- camera
- clothing
- furniture
- food
- fitness
- travel
- property
- investment

Recommended implementation:

- coherent monochrome SVG pixel-icon set
- consistent grid size
- no Emoji
- avoid mixing multiple icon libraries with incompatible stroke language

### Decorative assets

Observed:

- dotted separators
- corner glyphs
- star/spark forms in settlement
- NEW corner ribbons
- speech-bubble-like callout boxes

All are reconstructable with CSS/SVG.

Do not rasterize them from screenshots.

---

## 10. Interaction Map

### Observed

#### Shared

- one primary navigation tab is active
- settings is represented as an action
- current time / cash / net worth are passive status

#### Life

- speed selection has one active option
- start / pause controls have distinct states
- planner has defined activity cells
- inbox panels expose “view all” actions

#### Career

- filters exist
- search exists
- cards have different application states
- pagination exists
- selected job has a detail panel
- apply CTA exists

#### Shop

- category tabs exist
- cards expose add/select action
- cart supports removal
- purchase CTA exists
- wishlist exists
- selected item detail exists

#### Settlement

- continue CTA exists
- summary is a terminal/review state rather than normal page browsing

### Inferred

#### Hover / focus

Likely required for all desktop controls.  
Confidence: high.

#### Keyboard focus

Not visible but required for accessibility.  
Confidence: high.

#### Card selection

Career and Shop details imply selected card state.  
Confidence: high.

#### Mobile behavior

Not visible in these four screenshots.  
See responsive section.

#### Animation

Screenshots do not prove animation.

Allowed only where existing game behavior requires it, for example:

- running progress
- month settlement entrance
- selected state transition

Do not invent large decorative animations solely from the screenshots.

---

## 11. Responsive Behavior

### Observed

Only desktop 4:3 concept screens are available.

No mobile screenshot is part of this visual reference pack.

Therefore no exact mobile layout is visually proven.

### Inferred — conservative implementation

Existing product requirements may already define mobile behavior. Preserve those rules.

For these desktop compositions:

#### Shared

At narrow widths:

- keep status information compact;
- allow primary navigation horizontal scrolling or project-defined mobile navigation;
- do not shrink critical text below legibility.

#### Life

Possible stacking order:

```text
Current activity
Weekly forecast
Weekly planner (horizontal scroll if needed)
Inbox panels
```

#### Career

Desktop 3-region layout may collapse to:

```text
Filter controls
Job list
Selected job detail
```

Job details may become a drawer/page if the existing app has such a pattern.

#### Shop

Desktop catalog + sidebar may collapse to:

```text
Category controls
Catalog
Selected detail
Cart / schedule / owned / wishlist
```

#### Settlement

Main 4-column finance summary may become 1–2 columns.

### Constraint

Do not invent a new mobile IA purely from this spec.

Use existing app/mobile conventions where they exist.

---

## 12. Visual Hierarchy

### Shared attention flow

1. Current page / current major state
2. Primary numeric or decision surface
3. Main interactive content
4. Supporting detail
5. persistent secondary status

### Life page

Primary focal point:

- huge current time
- current activity

Secondary:

- start/pause/speed
- weekly planner

Supporting:

- weekly forecast
- inbox

Low priority:

- bottom attribute strip

### Career page

Primary:

- job market grid + selected job

Secondary:

- apply CTA
- requirements / match

Supporting:

- filters

Low priority:

- bottom market/history panels

### Shop page

Primary:

- catalog cards

Secondary:

- cart / selected item

Supporting:

- weekly schedule / owned / wishlist

Low priority:

- bottom attributes

### Settlement page

Primary:

- month title
- net-worth change

Secondary:

- income / expense / asset breakdown

Supporting:

- highlights

Final action:

- continue CTA

### Density and visual competition

The concept is intentionally dense.

Prevent visual competition through:

- size hierarchy
- inverted focal areas
- consistent panel titles
- tight component families
- limited number of border weights
- restrained decoration

Do not solve density by making everything tiny.

---

## 13. Uncertainty Register

### Item: exact font

Reason: concept image does not provide font metadata.  
Best estimate: Chinese-capable pixel/bitmap-like or strongly monospaced visual system.  
Confidence: low.  
Impact if wrong: medium-high; typography strongly affects identity.

### Item: exact CSS viewport

Reason: source is a generated concept image at 1448 × 1086, not browser telemetry.  
Best estimate: target ~1440 desktop composition.  
Confidence: medium.  
Impact if wrong: medium.

### Item: mascot / cat icon as permanent brand asset

Reason: visible in concept image but not proven as canonical game branding.  
Best estimate: optional pixel identity motif.  
Confidence: medium.  
Impact if wrong: low-medium.

### Item: exact hover / focus states

Reason: static screenshots only.  
Best estimate: use inversion/border emphasis.  
Confidence: high.  
Impact if wrong: low.

### Item: exact mobile composition

Reason: no mobile concept screenshot in this pack.  
Best estimate: conservative stacking based on existing app behavior.  
Confidence: low-medium.  
Impact if wrong: high.

### Item: exact grid breakpoints

Reason: only one desktop width shown.  
Best estimate: 3-column cards at ~1440; reduce columns when necessary.  
Confidence: medium.  
Impact if wrong: medium.

### Item: exact animation language

Reason: static screenshots.  
Best estimate: minimal pixel-style state transitions; no large ornamental motion.  
Confidence: low.  
Impact if wrong: low-medium.

### Item: month-end “S” grade

Reason: visible in concept image but conflicts with canonical product rule that the game does not judge the player's life.  
Best estimate: preserve card footprint, replace with neutral reflection / milestone content.  
Confidence: high.  
Impact if wrong: high product-semantics risk.

### Item: exact sample jobs/products/numbers

Reason: concept images use illustrative content.  
Best estimate: treat as presentation samples only.  
Confidence: high.  
Impact if wrong: high if hardcoded.

---

## 14. Implementation Directives

### 14.1 Source-of-truth precedence

For this UI overhaul, use this precedence:

1. **Existing repository/domain logic**  
   Source of truth for actual game state, actions, persistence and business behavior.

2. **Canonical 《余量》 product/content design document**  
   Source of truth for gameplay semantics, finance meanings, content intent and freedom-of-play rules.

3. **These four screenshots + this specification**  
   Source of truth for visual language, page composition, hierarchy and component appearance.

If visual mock content contradicts canonical product semantics, keep the visual structure but use the canonical semantics.

Do not “fix” existing game behavior merely to make a sample number in a screenshot true.

---

### 14.2 Fidelity priority

When visually matching the references, fix in this exact order:

1. Structure
2. Major proportions
3. Alignment
4. Spacing
5. Typography hierarchy
6. Black/white/gray contrast
7. Icon system
8. Borders / panel framing
9. Interaction state clarity
10. Micro-polish

Do not spend time on 1px decorative differences while the main composition is wrong.

---

### 14.3 Layout strategy

Prefer:

- semantic React component structure
- CSS Grid for page macro-layout
- nested Grid for card and planner regions
- Flexbox for toolbars / metric rows
- max-width or fluid desktop constraints
- shared CSS variables / tokens
- reusable pixel UI primitives

Avoid:

- absolute-positioning the full page
- hundreds of screenshot-specific pixel coordinates
- fixed image backgrounds
- canvas rendering for ordinary UI
- slicing screenshot fragments into assets
- one-off page-specific copies of the same button/card styles

The goal is:

> use correct web structure to naturally render pixels close to the references.

---

### 14.4 Component strategy

Build or refactor toward reusable primitives such as:

```text
PixelPanel
PixelButton
PixelTab
PixelIcon
StatusBadge
SegmentMeter
MetricBlock
PixelCard
PageSectionHeader
PersistentStatusBar
```

Then build domain-aware composites:

```text
ActivityHero
WeeklyPlanner
InboxPanel
JobCard
JobDetailPanel
RequirementComparison
CatalogCard
CatalogSidebar
SettlementFinancePanel
MonthlyHighlightCard
```

Do not put all new UI into `App.tsx`.

Do not duplicate the same pixel border/button system across pages.

---

### 14.5 Asset strategy

- Use a coherent monochrome pixel SVG icon set.
- Prefer reusable local SVGs/components.
- Do not use Emoji.
- Do not mix smooth Lucide-style thin strokes with chunky pixel icons unless deliberately pixel-adapted.
- Keep icons optically aligned on a common grid.
- Brand text should remain real selectable text.
- Decorative corner marks and dotted lines should be CSS/SVG, not raster crops.

---

### 14.6 Data binding

All UI must bind to live game data.

Never hardcode:

- `¥480`
- `¥500`
- `08:00`
- example job names
- example products
- example monthly totals
- example attribute values
- example dates

unless they are fixture/demo data used only in tests or Storybook-like development environments.

The production screen must render canonical state.

---

### 14.7 Financial correctness

Month settlement must preserve the established financial categories:

- income
- consumption expense
- asset allocation
- asset liquidation
- realized gain/loss
- unrealized valuation change

Do not report asset principal as income.

Do not merge valuation changes into cash flow.

Do not let visual totals disagree with the ledger.

---

### 14.8 Product philosophy constraints

Do not introduce through UI:

- player levels
- “life score”
- monthly / yearly grades
- required wealth progression
- forced life-stage labels
- mandatory entrepreneurship
- mandatory home ownership
- punitive relationship maintenance
- moralized spending feedback

The UI may show facts, milestones and changes.

It must not judge whether the player lived “correctly”.

---

### 14.9 Interaction constraints

Every visible action must connect to a real action/route/state transition.

No decorative fake controls.

Examples:

- `申请岗位` must dispatch the real application flow.
- `开始本周` must start the existing simulation.
- `暂停` must pause it.
- `结算购买` must use the real purchase path.
- wishlist controls must mutate real wishlist state if that feature exists.
- `进入下月` must respect canonical settlement/pause behavior.
- disabled actions must explain why when possible.

---

### 14.10 Desktop target

First obtain high fidelity at the primary desktop reference width.

Recommended primary screenshot target:

`~1440px wide`

At this width:

- 3-column career cards
- 3-column shop cards
- life weekly planner visible in one band
- right side panels visible without overlap
- bottom status bar remains readable

Only after the desktop structure is correct should responsive refinements be tuned.

---

### 14.11 Responsive constraints

The concept screenshots do not authorize inventing a completely new mobile design.

Reuse existing mobile product structure where possible.

At smaller widths:

- preserve hierarchy before preserving exact column count;
- allow grids to collapse;
- allow planner/table-like areas to scroll horizontally when semantically better than crushing text;
- never shrink Chinese text to illegible sizes;
- keep primary CTA visible and obvious.

---

### 14.12 Visual QA requirement

Do not consider the redesign complete from code review alone.

For each of the four reference screens:

1. start the real app;
2. navigate to a representative state;
3. capture a screenshot at the target desktop viewport;
4. compare with the matching reference image;
5. correct structure/proportion/alignment first;
6. repeat until the page clearly belongs to the same visual system.

Required comparison pairs:

```text
生活主循环     ↔ 01-life-main.png
招聘市场       ↔ 02-career-market.png
商店/生活内容  ↔ 03-shop-life.png
月结算         ↔ 04-month-settlement.png
```

Also verify:

- selected nav/tab states
- disabled buttons
- long Chinese titles
- large currency values
- empty states
- content overflow
- no console errors
- no horizontal page overflow at target desktop width

---

### 14.13 Completion criteria

The UI overhaul is not complete until:

- all four screens share one coherent design token system;
- the app visibly reads as a game rather than an admin dashboard;
- the life screen makes the auto-running loop dominant;
- career market cards and details are clearly game-like and actionable;
- shop/life content is browsable as a rich card catalog;
- month settlement has strong game feedback without turning into a score screen;
- all values are backed by real state;
- all primary buttons perform real actions;
- desktop fidelity has been browser-checked against the supplied references;
- existing gameplay semantics remain intact;
- responsive behavior remains usable;
- no screenshot is used as a background or positional crutch.

---

### 14.14 Final instruction to Coding Agent

Implement the four supplied concept screens as one unified visual redesign of the existing 《余量》 application.

Do not respond with a visual description only.
Do not create a disconnected mock demo.
Do not redesign game mechanics.
Do not hardcode screenshot content.
Do not stop after creating tokens or a component library.

Inspect the current repository first, map these visual regions to the real existing views/state/actions, then implement the redesign incrementally while preserving working game behavior.

After implementation, perform real browser screenshot comparison against all four supplied references and iterate on fidelity.

> Treat this specification and the supplied screenshot together as the source of truth. Where the specification contains an estimate, use the screenshot for visual judgment. Do not invent unseen product features or design states. Preserve semantic structure and reusable layout logic rather than hard-coding screenshot coordinates.
